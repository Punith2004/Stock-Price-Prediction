# Stock price prediction

This is a personal project which aims to predict stock price of Apple inc. using it's dataset. <br>
